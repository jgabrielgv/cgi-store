#!/usr/bin/python
"""This script shows the login page"""

#print "Content-type: text/html\n\n"

from helpers import embed_local_file
from helpers import pagetemplate
from helpers import replace
from helpers import ucgiprint
from helpers import loadhtml


css = '<link rel="stylesheet" type="text/css" href="css/styles.css">'
body = loadhtml('signin.html')
wholepage = pagetemplate.replace('**title**', 'Log In').replace('**css**', css).replace('**body**', body)
ucgiprint(wholepage)

#embed_local_file('signin.html')
